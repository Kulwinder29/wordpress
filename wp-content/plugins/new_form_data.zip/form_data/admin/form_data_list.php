<?php
  global $wpdb,$table_prefix;
  $form_data = $table_prefix. 'form_data';
  if(isset($_GET['my_search'])){
    $q = "SELECT * FROM `$form_data` WHERE `name` LIKE '%".$_GET['my_search']."%';";
  }else{
    $q = "SELECT * FROM `$form_data`";
  }
  // $q = "SELECT * FROM `$form_data`";
  $result =$wpdb->get_results($q);
 
  ?>

<div class="wrap">
  <h2>My Plugin Page</h2>
  <div class="my_form">
    <form action="<?php echo admin_url('admin.php') ;?>" id="my_search_form">
    <input type="hidden" name="page" value="form-data">
      <input type="text" name="my_search" id="my_search">
      <input type="submit" value="search" name="search">
    </form>
  </div>
</div>

  <table class="wp-list-table widefat fixed striped table-view-list posts">
    <tr>
      <th>Id</th>
      <th>Name</th>
      <th>Email</th>
      <th>Status</th>
    </tr>
 <?php foreach($result as $val){ ?>
  <tr>
      <td><?php echo $val->id ;?></td>
      <td><?php echo $val->name ;?></td>
      <td><?php echo $val->email ;?></td>
      <td><?php echo $val->status ;?></td>
    </tr>
    <?php } ?>
  </table> 
  <?php
// // Get the IP address of the user
// $ip_address = $_SERVER['REMOTE_ADDR'];

// // Print the IP address
// echo "Your IP address is: " . $ip_address;
// ?>

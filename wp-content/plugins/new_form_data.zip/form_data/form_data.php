<?php

/**
 * Plugin Name: Form Data 
 * Description: This is a test plugin.
 * Version: 1.0
 * Author: Kulwinder Singh
 */

use ParagonIE\Sodium\Core\Curve25519\Ge\P2;

use function PHPSTORM_META\type;

if (!defined('ABSPATH')) {
    header("location: /wordpress");
    die();
}

function form_data_activation()
{
    global $wpdb, $table_prefix;
    $form_data = $table_prefix . 'form_data';

    $q = "CREATE TABLE IF NOT EXISTS `$form_data` (`id` INT NOT NULL AUTO_INCREMENT , `name` VARCHAR(255) NOT NULL , `email` VARCHAR(255) NOT NULL , `status` BOOLEAN NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;";

    $wpdb->query($q);

    $data = array(
        'name' => 'Kulwinder Singh',
        'email' => 'kulwinder123@gmail.com',
        'status' => 1
    );

    $wpdb->insert($form_data, $data);
}

register_activation_hook(__FILE__, 'form_data_activation');

function form_data_deactivation()
{
    global $wpdb, $table_prefix;
    $form_data = $table_prefix . 'form_data';
    $q = "TRUNCATE `$form_data`";
    $wpdb->query($q);
}

register_deactivation_hook(__FILE__, 'form_data_deactivation');

function form_data_uninstall()
{
    global $wpdb, $table_prefix;
    $form_data = $table_prefix . 'form_data';
    $q = "DROP TABLE `$form_data`";
    $wpdb->query($q);
}

register_uninstall_hook(__FILE__, 'form_data_uninstall');

function form_data_menu()
{
    // add_menu_page('Form Data', 'Form Data', 8, __FILE__, 'form_data_list');


    add_menu_page('Form Data', 'Form Data', 'manage_options', 'form-data', 'form_data_list', '', 6);

    add_submenu_page('form-data', 'Form Data Main', 'Form Data Main', 'manage_options', 'form-data', 'form_data_list');

    add_submenu_page('form-data', 'Sub Form Data', 'Sub Form Data', 'manage_options', 'form-data-sub', 'sub_form_data_list');
}
add_action('admin_menu', 'form_data_menu');



function form_data_list()
{
    include 'admin/form_data_list.php';
}
function sub_form_data_list()
{
    // include 'form_data_list.php';
    echo 'hii';
}


// function enqueue_custom_styles() {

//     $path_style = plugins_url('css/custom-style.css',__FILE__);
//     $ver_style = filemtime(plugin_dir_path(__FILE__).'css/custom-style.css');
//     wp_enqueue_style( 'custom-styles',$path_style,'',$ver_style);
//   }
//   add_action( 'admin_enqueue_scripts', 'enqueue_custom_styles' );

function enqueue_custom_script()
{

    $path_js = plugins_url('js/main.js', __FILE__);
    $dep = array('jquery');
    $ver_js = filemtime(plugin_dir_path(__FILE__) . 'js/main.js');
    wp_enqueue_script('main-js', $path_js, $dep, $ver_js, true);
    wp_add_inline_script('main-js', 'var ajaxUrl = "' . admin_url('admin-ajax.php') . '";');
}
add_action('admin_enqueue_scripts', 'enqueue_custom_script');

function my_search_func()
{
    global $wpdb, $table_prefix;
    $form_data = $table_prefix . 'form_data';
    $my_search =$_POST['my_search'];
    // echo $my_search;

    if (!empty($my_search)) {
        $q = "SELECT * FROM `$form_data` WHERE `name` LIKE '%" . $my_search . "%';";
    } else {
        $q = "SELECT * FROM `$form_data`";
    }
    // $q = "SELECT * FROM `$form_data`";
    $result = $wpdb->get_results($q);
    echo '<pre>';
    print_r($result);
}

add_action('wp_ajax_my_search_func', 'my_search_func');

function my_shortcode()
{
    global $wpdb, $table_prefix;
    $form_data = $table_prefix . 'form_data';
    $q = "SELECT * FROM `$form_data`";
    $result = $wpdb->get_results($q);
?>
    <table>
        <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Email</th>
            <th>Status</th>
        </tr>
        <?php
        foreach ($result as $val) { ?>
            <tr>
                <td><?php echo $val->id; ?></td>
                <td><?php echo $val->name; ?></td>
                <td><?php echo $val->email; ?></td>
                <td><?php echo $val->status; ?></td>
            </tr>
        <?php } ?>
    </table>
    <?php

}
add_shortcode('my_shortcode', 'my_shortcode');

function show_post()
{
    $args = array(
        'post_type' => 'post',
        // 'posts_per_page' => '1',
        'orderby' => 'ID',
        'order' => 'DSC',
    );
    $query = new WP_Query($args);

    ob_start();
    if ($query->have_posts()) {
    ?>
        <ol>
            <?php
            while ($query->have_posts()) {
                $query->the_post();
                echo '<li><a href="' . get_the_permalink() . '">' . get_the_title() . '</a> - >' . get_the_content() . '</li>';
            }
            ?>

        </ol>
<?php
    }
    wp_resolve_post_date();
    $html = ob_get_clean();
    return $html;
}
add_shortcode('show_post', 'show_post');

function head_fun()
{
    if (is_single()) {
        global $post;
        $views = get_post_meta($post->ID, 'views', true);
        if ($views == '') {
            add_post_meta($post->ID, 'views', 1);
        } else {
            $views++;
            update_post_meta($post->ID, 'views', $views);
        }
        // echo get_post_meta($post->ID, 'views', true);
    }
}
add_action('wp_head', 'head_fun');

function views_count()
{
    global $post;

    return 'Total Views :' . get_post_meta($post->ID, 'views', true);
}
add_shortcode('views_count', 'views_count')

?>
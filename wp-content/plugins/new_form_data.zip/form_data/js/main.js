jQuery(document).ready(($) => {
    let search_form = $('#my_search_form');

    search_form.submit((e) => {
        e.preventDefault();
        let my_search = $('#my_search').val();
        let formData = new FormData();
        formData.append('action', 'my_search_func');
        formData.append('my_search', my_search);

        $.ajax({
            URL: ajaxUrl,
            type: 'post',
            data: formData,
            processData: false,
            contentData: false,
            success: (responce) => {
                console.log(responce);
            },
            error: () => {
                console.log('error');
            }

        })
    });
});


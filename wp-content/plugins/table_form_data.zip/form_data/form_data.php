<?php
/**
 * Plugin Name: Form Data 
 * Description: This is a test plugin.
 * Version: 1.0
 * Author: Kulwinder Singh
 */

use function PHPSTORM_META\type;

if(! defined('ABSPATH')){
    header("location: /wordpress");
    die();
}

function form_data_activation(){
    global $wpdb,$table_prefix;
    $form_data = $table_prefix.'form_data';

    $q = "CREATE TABLE IF NOT EXISTS `$form_data` (`id` INT NOT NULL AUTO_INCREMENT , `name` VARCHAR(255) NOT NULL , `email` VARCHAR(255) NOT NULL , `status` BOOLEAN NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;";

    $wpdb->query($q);

    $data = array(
        'name' => 'Kulwinder Singh',
        'email' => 'kulwinder123@gmail.com',
        'status' => 1
    );
    
        $wpdb->insert($form_data,$data);
}

register_activation_hook(__FILE__,'form_data_activation');

function form_data_deactivation(){
    global $wpdb,$table_prefix;
    $form_data = $table_prefix. 'form_data';

    $q = "TRUNCATE `$form_data`";
    $wpdb->query($q);

}

register_deactivation_hook(__FILE__,'form_data_deactivation');

function form_data_uninstall(){
    global $wpdb,$table_prefix;
    $form_data = $table_prefix. 'form_data';
    $q = "DROP TABLE `$form_data`";
    $wpdb->query($q);
}

register_uninstall_hook(__FILE__,'form_data_uninstall');

function form_data_menu(){
    add_menu_page('Form Data','Form Data',8,__FILE__,'form_data_list');
}
add_action('admin_menu','form_data_menu');

function form_data_list(){
    include 'form_data_list.php';
}


// function enqueue_custom_styles() {

//     $path_style = plugins_url('css/custom-style.css',__FILE__);
//     $ver_style = filemtime(plugin_dir_path(__FILE__).'css/custom-style.css');
//     wp_enqueue_style( 'custom-styles',$path_style,'',$ver_style);
//   }
//   add_action( 'admin_enqueue_scripts', 'enqueue_custom_styles' );

  function my_shortcode(){
    global $wpdb,$table_prefix;
    $form_data = $table_prefix. 'form_data';
    $q = "SELECT * FROM `$form_data`";
    $result =$wpdb->get_results($q); 
    ?>
    <table>
    <th>Id</th>
      <th>Name</th>
      <th>Email</th>
      <th>Status</th>
    </tr>
    <?php
    foreach($result as $val){ ?>
     <tr>
      <td><?php echo $val->id ;?></td>
      <td><?php echo $val->name ;?></td>
      <td><?php echo $val->email ;?></td>
      <td><?php echo $val->status ;?></td>
    </tr>
   <?php } ?>
    </table>
    <?php
  
  }
add_shortcode('my_shortcode','my_shortcode');
?>
<?php
function my_custom_scripts(){
  $path_style = plugins_url('css/style.css',__FILE__);
  $dep = array('bootstrap');
  $ver_style = filemtime(plugin_dir_path(__FILE__).'css/style.css');
  wp_enqueue_style('my_custom_style',$path_style,$dep,$ver_style);
}
add_action('wp_enquere_scripts','my_custom_scripts');
  global $wpdb,$table_prefix;
  $form_data = $table_prefix. 'form_data';
  $q = "SELECT * FROM `$form_data`";
  $result =$wpdb->get_results($q); ?>
  <table border="1" style="width:90%">
    <tr>
      <th>Id</th>
      <th>Name</th>
      <th>Email</th>
      <th>Status</th>
    </tr>
 <?php foreach($result as $val){ ?>
  <tr>
      <td><?php echo $val->id ;?></td>
      <td><?php echo $val->name ;?></td>
      <td><?php echo $val->email ;?></td>
      <td><?php echo $val->status ;?></td>
    </tr>
    <?php } ?>
  </table>
